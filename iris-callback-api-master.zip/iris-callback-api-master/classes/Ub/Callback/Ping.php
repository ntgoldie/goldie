<?php
class UbCallbackPing implements UbCallbackAction {
	function execute($userId, $object, $userbot, $message) {
		echo 'ok';
	}

}